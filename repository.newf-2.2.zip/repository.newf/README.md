- My first try at creating my own repository for xbmc. Thanks to drinfernoo's example. These files are for my own perosnal use. I take no credit for these these addons.

- For those who would like to add this repository in the file manger of kodi, it is simple. Please add link below as file manger source in kodi.

https://newf276.github.io/

Note for Kodi Matrix, this does not seem to work all the time, you may need to download the zip from that link and install manaully.
